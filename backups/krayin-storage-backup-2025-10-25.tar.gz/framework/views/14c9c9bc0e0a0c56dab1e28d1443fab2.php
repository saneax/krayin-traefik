<th <?php echo e($attributes->merge(['scope' => 'col', 'class' => 'whitespace-nowrap px-6 py-4 font-semibold'])); ?>>
    <?php echo e($slot); ?>

</th>
<?php /**PATH /var/www/html/laravel-crm/packages/agenticone/Admin/src/Providers/../Resources/views/components/table/th.blade.php ENDPATH**/ ?>