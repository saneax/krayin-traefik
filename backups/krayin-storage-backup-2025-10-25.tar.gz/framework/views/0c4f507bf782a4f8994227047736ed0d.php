<?php $__env->startComponent('admin::emails.layout'); ?>
    <div style="margin-bottom: 34px;">
        <p style="font-weight: bold;font-size: 20px;color: #121A26;line-height: 24px;margin-bottom: 24px">
            <?php echo app('translator')->get('admin::app.emails.common.user.dear', ['username' => $user_name]); ?>, 👋
        </p>

        <p style="font-size: 16px;color: #384860;line-height: 24px;">
            <?php echo app('translator')->get('admin::app.emails.common.user.create-body'); ?>
        </p>
    </div>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/laravel-crm/packages/agenticone/Admin/src/Providers/../Resources/views/emails/users/create.blade.php ENDPATH**/ ?>