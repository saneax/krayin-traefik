<tr <?php echo e($attributes->merge(['scope' => 'row', 'class' => 'border-b border-gray-200 dark:border-gray-800'])); ?>>
    <?php echo e($slot); ?>

</tr><?php /**PATH /var/www/html/laravel-crm/packages/agenticone/Admin/src/Providers/../Resources/views/components/table/thead/tr.blade.php ENDPATH**/ ?>