<?php echo view_render_event('admin.leads.index.kanban.toolbar.before'); ?>


<div class="flex justify-between">
    <div class="flex w-full items-center gap-x-1.5">
        <!-- Search Panel -->
        <?php echo $__env->make('admin::leads.index.kanban.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Filter -->
        <?php echo $__env->make('admin::leads.index.kanban.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="z-10 hidden w-full divide-y divide-gray-100 rounded bg-white shadow dark:bg-gray-900"></div>
    </div>

    <!-- View Switcher -->
    <?php echo $__env->make('admin::leads.index.view-switcher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php echo view_render_event('admin.leads.index.kanban.toolbar.after'); ?>

<?php /**PATH /var/www/html/laravel-crm/packages/Webkul/Admin/src/Providers/../Resources/views/leads/index/kanban/toolbar.blade.php ENDPATH**/ ?>