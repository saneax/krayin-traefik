<label <?php echo e($attributes->merge(['class' => 'mb-1.5 flex items-center gap-1 text-sm font-normal text-gray-800 dark:text-white'])); ?>>
    <?php echo e($slot); ?>

</label>
<?php /**PATH /var/www/html/laravel-crm/packages/Webkul/Admin/src/Providers/../Resources/views/components/form/control-group/label.blade.php ENDPATH**/ ?>