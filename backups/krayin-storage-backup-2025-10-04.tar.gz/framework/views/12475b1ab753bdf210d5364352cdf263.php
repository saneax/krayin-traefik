<v-avatar <?php echo e($attributes); ?>>
    <div class="flex h-9 w-9 rounded-full text-xs shimmer"></div>
</v-avatar>

<?php if (! $__env->hasRenderedOnce('daebb5f3-e57d-4fb7-b530-0266c65327fe')): $__env->markAsRenderedOnce('daebb5f3-e57d-4fb7-b530-0266c65327fe');
$__env->startPush('scripts'); ?>
    <script
        type="text/x-template"
        id="v-avatar-template"
    >
        <div
            class="flex h-9 w-9 items-center justify-center rounded-full text-xs font-medium"
            :class="colorClasses()"
        >
            {{ name.split(' ').map(word => word[0].toUpperCase()).join('') }}
        </div>
    </script>

    <script type="module">
        app.component('v-avatar', {
            template: '#v-avatar-template',

            props: {
                name: {
                    type: String,
                    default: '',
                },
            },

            data() {
                return {
                    colors: {
                        background: [
                            'bg-yellow-200',
                            'bg-red-200',
                            'bg-lime-200',
                            'bg-blue-200',
                            'bg-orange-200',
                            'bg-green-200',
                            'bg-pink-200',
                            'bg-yellow-400'
                        ],

                        text: [
                            'text-yellow-900',
                            'text-red-900',
                            'text-lime-900',
                            'text-blue-900',
                            'text-orange-900',
                            'text-green-900',
                            'text-pink-900',
                            'text-yellow-900',
                        ],
                    },
                }
            },

            methods: {
                colorClasses() {
                    let index = Math.floor(Math.random() * this.colors.background.length);

                    return [
                        this.colors.background[index],
                        this.colors.text[index],
                    ];
                },
            },
        });
    </script>
<?php $__env->stopPush(); endif; ?><?php /**PATH /var/www/html/laravel-crm/packages/Webkul/Admin/src/Providers/../Resources/views/components/avatar/index.blade.php ENDPATH**/ ?>