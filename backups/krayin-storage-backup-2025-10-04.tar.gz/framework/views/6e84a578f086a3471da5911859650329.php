<li <?php echo e($attributes->merge(['class' => 'cursor-pointer px-5 py-2 text-sm text-gray-800 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-950 '])); ?>>
    <?php echo e($slot); ?>

</li>
<?php /**PATH /var/www/html/laravel-crm/packages/Webkul/Admin/src/Providers/../Resources/views/components/dropdown/menu/item.blade.php ENDPATH**/ ?>