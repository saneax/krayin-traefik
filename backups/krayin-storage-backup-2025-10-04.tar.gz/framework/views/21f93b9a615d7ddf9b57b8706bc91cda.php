<?php $__env->startComponent('admin::emails.layouts.master'); ?>
    <div style="text-align: center;">
        <a href="<?php echo e(config('app.url')); ?>">
            <img src="<?php echo e(asset('vendor/webkul/admin/assets/images/logo.svg')); ?>" alt="<?php echo e(config('app.name')); ?>"/>
        </a>
    </div>

    <div style="padding: 30px;">
        <div style="font-size: 20px;color: #242424;line-height: 30px;margin-bottom: 34px;">
            <p style="font-size: 16px;color: #5E5E5E;line-height: 24px;">
                <?php echo e(__('admin::app.mail.forget-password.dear', ['name' => $user_name])); ?>,
            </p>

            <p style="font-size: 16px;color: #5E5E5E;line-height: 24px;">
                <?php echo e(__('admin::app.mail.user.create-body')); ?>

            </p>
        </div>
    </div>
<?php echo $__env->renderComponent(); ?><?php /**PATH /var/www/html/laravel-crm/packages/Webkul/Admin/src/Providers/../Resources/views/emails/users/create.blade.php ENDPATH**/ ?>