<div <?php echo e($attributes->merge(['class' => 'mb-4'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /var/www/html/laravel-crm/packages/Webkul/Admin/src/Providers/../Resources/views/components/form/control-group/index.blade.php ENDPATH**/ ?>